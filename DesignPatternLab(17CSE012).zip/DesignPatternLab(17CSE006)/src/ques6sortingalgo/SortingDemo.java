package ques6sortingalgo;

public class SortingDemo {
	public static void main(String[] args) {
        Context context = new Context(new BubbleSort());
        System.out.println("The Sorting Method is = " + context.executeStrategy("Sort"));

        context = new Context(new QuickSort());
        System.out.println("The Sorting Method is = " + context.executeStrategy("Sort"));

        context = new Context(new InsertionSort());
        System.out.println("The Sorting Method is = " + context.executeStrategy("Sort"));
        
        context = new Context(new MargeSort());
        System.out.println("The Sorting Method is = " + context.executeStrategy("Sort"));
    }
}
