package ques6sortingalgo;

public class MargeSort implements SortingStrategy{
	@Override
	public String doOperation(String s) {
		s="Marge Sort";
        return s;
    }
}