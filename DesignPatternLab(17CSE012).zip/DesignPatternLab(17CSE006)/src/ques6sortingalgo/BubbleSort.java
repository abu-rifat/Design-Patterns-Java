package ques6sortingalgo;

public class BubbleSort implements SortingStrategy{
	@Override
    public String doOperation(String s) {
		s="Bubble Sort";
        return s;
    }
}