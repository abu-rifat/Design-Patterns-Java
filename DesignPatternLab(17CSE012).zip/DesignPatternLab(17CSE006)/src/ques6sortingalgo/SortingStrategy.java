package ques6sortingalgo;

public interface SortingStrategy {
	public String doOperation(String s);
}
