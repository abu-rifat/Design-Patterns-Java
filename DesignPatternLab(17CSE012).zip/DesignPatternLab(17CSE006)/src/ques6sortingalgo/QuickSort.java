package ques6sortingalgo;

public class QuickSort implements SortingStrategy{
	@Override
	public String doOperation(String s) {
		s="Quick Sort";
        return s;
    }
}