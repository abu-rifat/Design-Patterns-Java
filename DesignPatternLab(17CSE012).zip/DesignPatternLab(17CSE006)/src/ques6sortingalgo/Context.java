package ques6sortingalgo;

public class Context {
	private SortingStrategy sortingstrategy;

    public Context(SortingStrategy sortingstrategy) {
        this.sortingstrategy = sortingstrategy;
    }

    public String executeStrategy(String s) {
        return sortingstrategy.doOperation(s);
    }
}
