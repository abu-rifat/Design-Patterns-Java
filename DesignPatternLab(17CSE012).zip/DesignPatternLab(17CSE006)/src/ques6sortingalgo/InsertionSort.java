package ques6sortingalgo;

public class InsertionSort implements SortingStrategy{
	@Override
	public String doOperation(String s) {
		s="Insertion Sort";
        return s;
    }
}